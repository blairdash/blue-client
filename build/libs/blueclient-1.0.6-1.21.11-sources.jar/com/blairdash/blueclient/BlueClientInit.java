package com.blairdash.blueclient;

import com.blairdash.blueclient.features.ArmorHud;
import com.blairdash.blueclient.features.CheatWatch;
import com.blairdash.blueclient.features.CoordinatesHud;
import com.blairdash.blueclient.features.CpsFpsHud;
import com.blairdash.blueclient.features.CrosshairOverlay;
import com.blairdash.blueclient.features.Keystrokes;
import com.blairdash.blueclient.features.MotionBlurEffect;
import com.blairdash.blueclient.features.ZoomFeature;
import com.blairdash.blueclient.features.PotionHud;
import com.blairdash.blueclient.net.RankService;
import com.blairdash.blueclient.gui.BlueClientScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class BlueClientInit implements ClientModInitializer {
    private static final class_304.class_11900 CATEGORY =
            class_304.class_11900.method_74698(class_2960.method_60655("clientmod", "main"));

    // Opens/closes the mod menu overlay -- Right Shift, as requested.
    public static class_304 openMenuKey;
    // Held to zoom, like Lunar/OptiFine's default zoom bind.
    public static class_304 zoomKey;

    @Override
    public void onInitializeClient() {
        CrosshairConfigStorage.load();
        RankService.start();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.clientmod.openmenu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                CATEGORY));

        zoomKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.clientmod.zoom",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_C,
                CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openMenuKey.method_1436() && client.field_1755 == null) {
                client.method_1507(new BlueClientScreen());
            }
            CpsFpsHud.tick(client);
            CheatWatch.tick(client);
            ZoomFeature.tick(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            class_310 client = class_310.method_1551();
            if (ModConfig.cpsFpsHudEnabled) CpsFpsHud.render(drawContext, client);
            if (ModConfig.coordinatesHudEnabled) CoordinatesHud.render(drawContext, client);
            if (ModConfig.potionHudEnabled) PotionHud.render(drawContext, client);
            if (ModConfig.armorHudEnabled) ArmorHud.render(drawContext, client);
            if (ModConfig.keystrokesEnabled) Keystrokes.render(drawContext, client);
            if (ModConfig.cheatWatchEnabled) CheatWatch.render(drawContext, client);
        });

        CrosshairOverlay.register();
        MotionBlurEffect.register();
    }
}