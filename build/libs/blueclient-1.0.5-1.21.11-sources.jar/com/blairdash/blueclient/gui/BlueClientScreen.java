package com.blairdash.blueclient.gui;

import com.blairdash.blueclient.CrosshairConfigStorage;
import com.blairdash.blueclient.ModConfig;
import java.util.function.Consumer;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class BlueClientScreen extends class_437 {
    private enum Tab { MODS, COSMETICS }
    private Tab activeTab = Tab.MODS;

    private static final int COL_WIDTH = 200;
    private static final int COL_GAP = 8;
    private static final int START_Y = 55;
    private static final int ROW_HEIGHT = 24;

    private class_4185 crosshairButton;

    public BlueClientScreen() {
        super(class_2561.method_43470("Blue Client"));
    }

    @Override
    protected void method_25426() {
        int tabY = 20;
        method_37063(class_4185.method_46430(class_2561.method_43470("Mods"), b -> { activeTab = Tab.MODS; rebuild(); })
                .method_46434(field_22789 / 2 - 105, tabY, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cosmetics"), b -> { activeTab = Tab.COSMETICS; rebuild(); })
                .method_46434(field_22789 / 2 + 5, tabY, 100, 20).method_46431());

        if (activeTab == Tab.MODS) buildModsTab();
        else buildCosmeticsTab();
    }

    private void rebuild() {
        method_37067();
        method_25426();
    }

    private int slotX(int index) {
        return (index % 2 == 0)
                ? field_22789 / 2 - COL_WIDTH - COL_GAP / 2
                : field_22789 / 2 + COL_GAP / 2;
    }

    private int slotY(int index) {
        return START_Y + (index / 2) * ROW_HEIGHT;
    }

    private void buildModsTab() {
        addToggle(0, "Zoom (hold C)", ModConfig.zoomEnabled, v -> ModConfig.zoomEnabled = v);
        crosshairButton = addToggle(1, "Crosshair (right-click)", ModConfig.customCrosshairEnabled, v -> ModConfig.customCrosshairEnabled = v);
        addToggle(2, "CPS / FPS Display", ModConfig.cpsFpsHudEnabled, v -> ModConfig.cpsFpsHudEnabled = v);
        addToggle(3, "Coordinates", ModConfig.coordinatesHudEnabled, v -> ModConfig.coordinatesHudEnabled = v);
        addToggle(4, "Motion Blur", ModConfig.motionBlurEnabled, v -> ModConfig.motionBlurEnabled = v);
        addToggle(5, "Self Nametag (F5)", ModConfig.selfNametagEnabled, v -> ModConfig.selfNametagEnabled = v);
        addToggle(6, "Potion HUD", ModConfig.potionHudEnabled, v -> ModConfig.potionHudEnabled = v);
        addToggle(7, "Armor HUD", ModConfig.armorHudEnabled, v -> ModConfig.armorHudEnabled = v);
        addToggle(8, "Low Fire", ModConfig.lowFireEnabled, v -> ModConfig.lowFireEnabled = v);
        addToggle(9, "Low Shield", ModConfig.lowShieldEnabled, v -> ModConfig.lowShieldEnabled = v);
        addToggle(10, "Cheat Watch (risky)", ModConfig.cheatWatchEnabled, v -> ModConfig.cheatWatchEnabled = v);
        addToggle(11, "Keystrokes", ModConfig.keystrokesEnabled, v -> ModConfig.keystrokesEnabled = v);

        method_37063(class_4185.method_46430(class_2561.method_43470("HUD Positions..."),
                        b -> class_310.method_1551().method_1507(new HudPositionScreen(this)))
                .method_46434(slotX(12), slotY(12), COL_WIDTH, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Fire / Shield Offsets..."),
                        b -> class_310.method_1551().method_1507(new ViewOffsetScreen(this)))
                .method_46434(slotX(13), slotY(13), COL_WIDTH, 20).method_46431());
    }

    private void buildCosmeticsTab() {
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Cosmetics need a backend (see README) -- none loaded"),
                b -> {}).method_46434(field_22789 / 2 - 150, 60, 300, 20).method_46431());
    }

    private class_4185 addToggle(int slot, String label, boolean initial, Consumer<Boolean> onChange) {
        boolean[] state = { initial };
        class_4185 button = class_4185.method_46430(toggleText(label, state[0]), b -> {
            state[0] = !state[0];
            onChange.accept(state[0]);
            b.method_25355(toggleText(label, state[0]));
            CrosshairConfigStorage.save();
        }).method_46434(slotX(slot), slotY(slot), COL_WIDTH, 20).method_46431();
        method_37063(button);
        return button;
    }

    private class_2561 toggleText(String label, boolean on) {
        return class_2561.method_43470(label + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        if (button == 1 && crosshairButton != null && activeTab == Tab.MODS) {
            int bx = crosshairButton.method_46426();
            int by = crosshairButton.method_46427();
            int bw = crosshairButton.method_25368();
            int bh = crosshairButton.method_25364();
            if (mouseX >= bx && mouseX < bx + bw && mouseY >= by && mouseY < by + bh) {
                class_310.method_1551().method_1507(new CrosshairSettingsScreen(this));
                return true;
            }
        }
        return super.method_25402(click, doubleClick);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 6, 0xFFFFFFFF);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}