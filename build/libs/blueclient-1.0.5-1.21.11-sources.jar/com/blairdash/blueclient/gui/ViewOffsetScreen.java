package com.blairdash.blueclient.gui;

import com.blairdash.blueclient.CrosshairConfigStorage;
import com.blairdash.blueclient.ModConfig;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Set how far Low Fire and Low Shield move things down (larger = lower). */
public class ViewOffsetScreen extends class_437 {
    private static final float FIRE_MAX = 0.80f;
    private static final float SHIELD_MAX = 0.80f;
    private static final float FIRE_DEFAULT = 0.45f;
    private static final float SHIELD_DEFAULT = 0.25f;

    private final class_437 parent;
    private class_342 fireField;
    private class_342 shieldField;

    public ViewOffsetScreen(class_437 parent) {
        super(class_2561.method_43470("Fire & Shield Offsets"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;

        fireField = field(centerX + 30, 56, ModConfig.lowFireOffset);
        shieldField = field(centerX + 30, 84, ModConfig.lowShieldOffset);

        int buttonsY = 122;
        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), b -> saveAndClose())
                .method_46434(centerX - 126, buttonsY, 80, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Reset"), b -> resetToDefaults())
                .method_46434(centerX - 40, buttonsY, 80, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(centerX + 46, buttonsY, 80, 20).method_46431());
    }

    private class_342 field(int x, int y, float value) {
        class_342 f = new class_342(field_22793, x, y, 70, 20, class_2561.method_43470(""));
        f.method_1880(6);
        f.method_1852(String.format(Locale.ROOT, "%.2f", value));
        method_37063(f);
        return f;
    }

    private static float parse(class_342 f, float fallback, float max) {
        try {
            float v = Float.parseFloat(f.method_1882().trim().replace(',', '.'));
            return Math.max(0.0f, Math.min(v, max));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private void saveAndClose() {
        ModConfig.lowFireOffset = parse(fireField, ModConfig.lowFireOffset, FIRE_MAX);
        ModConfig.lowShieldOffset = parse(shieldField, ModConfig.lowShieldOffset, SHIELD_MAX);
        CrosshairConfigStorage.save();
        method_25419();
    }

    private void resetToDefaults() {
        ModConfig.lowFireOffset = FIRE_DEFAULT;
        ModConfig.lowShieldOffset = SHIELD_DEFAULT;
        CrosshairConfigStorage.save();
        method_37067();
        method_25426();
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = field_22789 / 2;
        context.method_27534(field_22793, field_22785, centerX, 20, 0xFFFFFFFF);

        int labelX = centerX - 130;
        context.method_25303(field_22793, "Low Fire offset (0 - 0.80)", labelX, 62, 0xFFFFFFFF);
        context.method_25303(field_22793, "Low Shield offset (0 - 0.80)", labelX, 90, 0xFFFFFFFF);

        context.method_25300(field_22793, "Larger = lower. Turn each on from the main menu.",
                centerX, 156, 0xFFAAAAAA);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}