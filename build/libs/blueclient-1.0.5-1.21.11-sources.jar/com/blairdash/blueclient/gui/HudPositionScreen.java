package com.blairdash.blueclient.gui;

import com.blairdash.blueclient.CrosshairConfigStorage;
import com.blairdash.blueclient.ModConfig;
import com.blairdash.blueclient.features.ArmorHud;
import com.blairdash.blueclient.features.CoordinatesHud;
import com.blairdash.blueclient.features.Keystrokes;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Set the X/Y position of the CPS/FPS display, Potion HUD, Coordinates, Armor HUD, and Keystrokes. */
public class HudPositionScreen extends class_437 {
    private final class_437 parent;

    private class_342 cpsX, cpsY, potionX, potionY, coordsX, coordsY, armorX, armorY, keysX, keysY;
    private int xColumn, yColumn;
    private int coordsDefaultX, coordsDefaultY, armorDefaultX, armorDefaultY, keysDefaultX, keysDefaultY;

    public HudPositionScreen(class_437 parent) {
        super(class_2561.method_43470("HUD Positions"));
        this.parent = parent;
    }

    private static int rowY(int row) {
        return 54 + row * 24;
    }

    @Override
    protected void method_25426() {
        class_310 client = class_310.method_1551();
        int centerX = field_22789 / 2;
        xColumn = centerX - 30;
        yColumn = centerX + 40;

        cpsX = field(xColumn, rowY(0), ModConfig.cpsFpsX);
        cpsY = field(yColumn, rowY(0), ModConfig.cpsFpsY);

        potionX = field(xColumn, rowY(1), ModConfig.potionHudX);
        potionY = field(yColumn, rowY(1), ModConfig.potionHudY);

        coordsDefaultX = CoordinatesHud.effectiveX(client, field_22789);
        coordsDefaultY = CoordinatesHud.effectiveY();
        coordsX = field(xColumn, rowY(2), coordsDefaultX);
        coordsY = field(yColumn, rowY(2), coordsDefaultY);

        armorDefaultX = ArmorHud.effectiveX(field_22789);
        armorDefaultY = ArmorHud.effectiveY(field_22790);
        armorX = field(xColumn, rowY(3), armorDefaultX);
        armorY = field(yColumn, rowY(3), armorDefaultY);

        keysDefaultX = Keystrokes.effectiveX();
        keysDefaultY = Keystrokes.effectiveY(field_22790);
        keysX = field(xColumn, rowY(4), keysDefaultX);
        keysY = field(yColumn, rowY(4), keysDefaultY);

        int buttonsY = rowY(4) + 32;
        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), b -> saveAndClose())
                .method_46434(centerX - 126, buttonsY, 80, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Reset"), b -> resetToDefaults())
                .method_46434(centerX - 40, buttonsY, 80, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(centerX + 46, buttonsY, 80, 20).method_46431());
    }

    private class_342 field(int x, int y, int value) {
        class_342 f = new class_342(field_22793, x, y, 60, 20, class_2561.method_43470(""));
        f.method_1880(5);
        f.method_1852(String.valueOf(value));
        method_37063(f);
        return f;
    }

    private static int parse(class_342 f, int fallback, int max) {
        try {
            int v = Integer.parseInt(f.method_1882().trim());
            return Math.max(0, Math.min(v, max));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private void saveAndClose() {
        ModConfig.cpsFpsX = parse(cpsX, ModConfig.cpsFpsX, field_22789 - 1);
        ModConfig.cpsFpsY = parse(cpsY, ModConfig.cpsFpsY, field_22790 - 1);
        ModConfig.potionHudX = parse(potionX, ModConfig.potionHudX, field_22789 - 1);
        ModConfig.potionHudY = parse(potionY, ModConfig.potionHudY, field_22790 - 1);

        // Coordinates, Armor HUD and Keystrokes: if still on the automatic default and the
        // value wasn't changed, keep it automatic instead of freezing it.
        int cx = parse(coordsX, coordsDefaultX, field_22789 - 1);
        int cy = parse(coordsY, coordsDefaultY, field_22790 - 1);
        ModConfig.coordsX = (ModConfig.coordsX < 0 && cx == coordsDefaultX) ? -1 : cx;
        ModConfig.coordsY = (ModConfig.coordsY < 0 && cy == coordsDefaultY) ? -1 : cy;

        int ax = parse(armorX, armorDefaultX, field_22789 - 1);
        int ay = parse(armorY, armorDefaultY, field_22790 - 1);
        ModConfig.armorHudX = (ModConfig.armorHudX < 0 && ax == armorDefaultX) ? -1 : ax;
        ModConfig.armorHudY = (ModConfig.armorHudY < 0 && ay == armorDefaultY) ? -1 : ay;

        int kx = parse(keysX, keysDefaultX, field_22789 - 1);
        int ky = parse(keysY, keysDefaultY, field_22790 - 1);
        ModConfig.keystrokesX = (ModConfig.keystrokesX < 0 && kx == keysDefaultX) ? -1 : kx;
        ModConfig.keystrokesY = (ModConfig.keystrokesY < 0 && ky == keysDefaultY) ? -1 : ky;

        CrosshairConfigStorage.save();
        method_25419();
    }

    private void resetToDefaults() {
        ModConfig.cpsFpsX = 6;
        ModConfig.cpsFpsY = 6;
        ModConfig.potionHudX = 6;
        ModConfig.potionHudY = 34;
        ModConfig.coordsX = -1;
        ModConfig.coordsY = -1;
        ModConfig.armorHudX = -1;
        ModConfig.armorHudY = -1;
        ModConfig.keystrokesX = -1;
        ModConfig.keystrokesY = -1;
        CrosshairConfigStorage.save();
        method_37067();
        method_25426();
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = field_22789 / 2;
        context.method_27534(field_22793, field_22785, centerX, 14, 0xFFFFFFFF);

        context.method_25300(field_22793, "X", xColumn + 30, 40, 0xFFAAAAAA);
        context.method_25300(field_22793, "Y", yColumn + 30, 40, 0xFFAAAAAA);

        int labelX = centerX - 110;
        context.method_25303(field_22793, "CPS / FPS", labelX, rowY(0) + 6, 0xFFFFFFFF);
        context.method_25303(field_22793, "Potion HUD", labelX, rowY(1) + 6, 0xFFFFFFFF);
        context.method_25303(field_22793, "Coordinates", labelX, rowY(2) + 6, 0xFFFFFFFF);
        context.method_25303(field_22793, "Armor HUD", labelX, rowY(3) + 6, 0xFFFFFFFF);
        context.method_25303(field_22793, "Keystrokes", labelX, rowY(4) + 6, 0xFFFFFFFF);

        int noteY = rowY(4) + 58;
        context.method_25300(field_22793, "X / Y = pixels from the top-left of the screen.", centerX, noteY, 0xFFAAAAAA);
        context.method_25300(field_22793, "Armor HUD / Keystrokes: top-left of the display.", centerX, noteY + 11, 0xFFAAAAAA);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}