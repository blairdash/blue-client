package com.blairdash.blueclient.gui;

import com.blairdash.blueclient.CrosshairConfigStorage;
import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CrosshairSettingsScreen extends class_437 {
    private final class_437 parent;

    private class_342 colorField;
    private class_342 sizeField;
    private class_342 thicknessField;
    private class_342 gapField;
    private class_342 enemyColorField;

    private boolean enemyEnabled;
    private class_4185 enemyToggleButton;

    public CrosshairSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Custom Crosshair"));
        this.parent = parent;
        this.enemyEnabled = ModConfig.enemyCrosshairEnabled;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int y = 50;
        int fieldWidth = 200;

        colorField = new class_342(field_22793, centerX - fieldWidth / 2, y, fieldWidth, 20, class_2561.method_43470("Color"));
        colorField.method_1880(8);
        colorField.method_1852(String.format("%08X", ModConfig.crosshairColor));
        method_37063(colorField);
        y += 28;

        sizeField = new class_342(field_22793, centerX - fieldWidth / 2, y, fieldWidth, 20, class_2561.method_43470("Size"));
        sizeField.method_1852(String.valueOf((int) ModConfig.crosshairSize));
        method_37063(sizeField);
        y += 28;

        thicknessField = new class_342(field_22793, centerX - fieldWidth / 2, y, fieldWidth, 20, class_2561.method_43470("Thickness"));
        thicknessField.method_1852(String.valueOf((int) ModConfig.crosshairThickness));
        method_37063(thicknessField);
        y += 28;

        gapField = new class_342(field_22793, centerX - fieldWidth / 2, y, fieldWidth, 20, class_2561.method_43470("Gap"));
        gapField.method_1852(String.valueOf((int) ModConfig.crosshairGap));
        method_37063(gapField);
        y += 36;

        enemyToggleButton = class_4185.method_46430(enemyToggleText(), b -> {
            enemyEnabled = !enemyEnabled;
            b.method_25355(enemyToggleText());
        }).method_46434(centerX - fieldWidth / 2, y, fieldWidth, 20).method_46431();
        method_37063(enemyToggleButton);
        y += 28;

        enemyColorField = new class_342(field_22793, centerX - fieldWidth / 2, y, fieldWidth, 20, class_2561.method_43470("Enemy Color"));
        enemyColorField.method_1880(8);
        enemyColorField.method_1852(String.format("%08X", ModConfig.enemyCrosshairColor));
        method_37063(enemyColorField);
        y += 36;

        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), b -> saveAndClose())
                .method_46434(centerX - 104, y, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(centerX + 4, y, 100, 20).method_46431());
    }

    private class_2561 enemyToggleText() {
        return class_2561.method_43470("Enemy Crosshair: " + (enemyEnabled ? "ON" : "OFF"));
    }

    private void saveAndClose() {
        try {
            ModConfig.crosshairColor = (int) Long.parseLong(colorField.method_1882().trim(), 16);
        } catch (NumberFormatException ignored) { }
        try {
            ModConfig.enemyCrosshairColor = (int) Long.parseLong(enemyColorField.method_1882().trim(), 16);
        } catch (NumberFormatException ignored) { }
        ModConfig.crosshairSize = parseFloatSafe(sizeField.method_1882(), ModConfig.crosshairSize);
        ModConfig.crosshairThickness = parseFloatSafe(thicknessField.method_1882(), ModConfig.crosshairThickness);
        ModConfig.crosshairGap = parseFloatSafe(gapField.method_1882(), ModConfig.crosshairGap);
        ModConfig.enemyCrosshairEnabled = enemyEnabled;
        CrosshairConfigStorage.save();
        method_25419();
    }

    private static float parseFloatSafe(String text, float fallback) {
        try {
            return Float.parseFloat(text.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, class_2561.method_43470("Colors are ARGB hex, e.g. FFFFFFFF"), field_22789 / 2, 36, 0xFFAAAAAA);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}