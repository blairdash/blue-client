package com.blairdash.blueclient.mixin;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lowers the shield in first person (either hand) by shifting the matrix
 * down before the item is rendered and restoring it afterwards, so the
 * other hand and the fire overlay aren't affected.
 */
@Mixin(class_759.class)
public class LowShieldMixin {

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void clientmod$lowerShieldStart(class_742 player, float tickProgress, float pitch,
                                            class_1268 hand, float swingProgress, class_1799 item, float equipProgress,
                                            class_4587 matrices, class_11659 orderedRenderCommandQueue,
                                            int light, CallbackInfo ci) {
        if (ModConfig.lowShieldEnabled && item.method_31574(class_1802.field_8255)) {
            matrices.method_22903();
            matrices.method_46416(0.0F, -ModConfig.lowShieldOffset, 0.0F);
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void clientmod$lowerShieldEnd(class_742 player, float tickProgress, float pitch,
                                          class_1268 hand, float swingProgress, class_1799 item, float equipProgress,
                                          class_4587 matrices, class_11659 orderedRenderCommandQueue,
                                          int light, CallbackInfo ci) {
        if (ModConfig.lowShieldEnabled && item.method_31574(class_1802.field_8255)) {
            matrices.method_22909();
        }
    }
}