package com.blairdash.blueclient.mixin;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * PlayerEntityRenderer overrides EntityRenderer's hasLabel with its own
 * version (parameter type PlayerLikeEntity, not Entity) -- that's the one
 * that actually runs for players, so this has to target this class
 * specifically rather than the base EntityRenderer.
 */
@Mixin(class_1007.class)
public class SelfNametagMixin {

    @Inject(method = "hasLabel", at = @At("RETURN"), cancellable = true)
    private void clientmod$forceOwnLabel(class_11890 entity, double squaredDistanceToCamera, CallbackInfoReturnable<Boolean> cir) {
        if (!ModConfig.selfNametagEnabled) return;
        class_310 client = class_310.method_1551();
        if (entity == client.field_1724 && !client.field_1690.method_31044().method_31034()) {
            cir.setReturnValue(true);
        }
    }
}