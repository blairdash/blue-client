package com.blairdash.blueclient.mixin;

import com.blairdash.blueclient.net.RankService;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public abstract class SelfNametagIconMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void blueclient$prependRankStar(class_1297 entity, CallbackInfoReturnable<class_2561> cir) {
        if (!(entity instanceof class_1657 player)) return;

        Integer color = RankService.colorFor(player.method_5667());
        if (color == null) return; // not a currently-online Blue Client user — leave the name untouched

        class_5250 star = class_2561.method_43470("\u2605 ")
                .method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(color & 0xFFFFFF)));
        cir.setReturnValue(star.method_10852(cir.getReturnValue()));
    }
}