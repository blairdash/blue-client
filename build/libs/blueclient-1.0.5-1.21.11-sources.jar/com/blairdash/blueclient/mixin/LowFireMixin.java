package com.blairdash.blueclient.mixin;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_1058;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lowers the first-person fire overlay by shifting the matrix down before
 * the overlay is drawn, then restoring it afterwards so the other overlays
 * (underwater, in-wall) aren't moved too. renderFireOverlay is static, so
 * the handlers have to be static as well.
 */
@Mixin(class_4603.class)
public class LowFireMixin {

    @Inject(method = "renderFireOverlay", at = @At("HEAD"))
    private static void clientmod$lowerFireStart(class_4587 matrices, class_4597 vertexConsumers,
                                                 class_1058 sprite, CallbackInfo ci) {
        if (ModConfig.lowFireEnabled) {
            matrices.method_22903();
            matrices.method_46416(0.0F, -ModConfig.lowFireOffset, 0.0F);
        }
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"))
    private static void clientmod$lowerFireEnd(class_4587 matrices, class_4597 vertexConsumers,
                                               class_1058 sprite, CallbackInfo ci) {
        if (ModConfig.lowFireEnabled) {
            matrices.method_22909();
        }
    }
}