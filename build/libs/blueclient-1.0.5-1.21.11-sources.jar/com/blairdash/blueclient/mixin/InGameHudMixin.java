package com.blairdash.blueclient.mixin;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void clientmod$cancelVanillaCrosshair(class_332 drawContext, class_9779 tickCounter, CallbackInfo ci) {
        if (ModConfig.customCrosshairEnabled) {
            ci.cancel();
        }
    }

    // Hides vanilla's effect icons (top-right) while our Potion HUD is on,
    // so the two don't show the same information twice.
    @Inject(method = "renderStatusEffectOverlay", at = @At("HEAD"), cancellable = true)
    private void clientmod$cancelVanillaEffects(class_332 drawContext, class_9779 tickCounter, CallbackInfo ci) {
        if (ModConfig.potionHudEnabled) {
            ci.cancel();
        }
    }
}