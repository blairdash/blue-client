package com.blairdash.blueclient.features;

import com.blairdash.blueclient.BlueClientInit;
import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_310;
import net.minecraft.class_7172;

/**
 * Smoothly interpolates FOV down while the zoom key is held, and back up
 * when released. Hooking client.options.getFov() every tick is the
 * simplest approach that works without mixins into the render pipeline.
 */
public class ZoomFeature {
    private static double currentFovOverride = -1; // -1 = not zoomed
    private static double normalFov;
    private static boolean wasZooming = false;

    public static void tick(class_310 client) {
        if (!ModConfig.zoomEnabled || client.field_1724 == null) {
            return;
        }
        boolean zooming = BlueClientInit.zoomKey.method_1434();
        class_7172<Integer> fovOption = client.field_1690.method_41808();

        if (zooming && !wasZooming) {
            normalFov = fovOption.method_41753();
        }

        if (zooming) {
            currentFovOverride = lerp(currentFovOverride < 0 ? normalFov : currentFovOverride,
                    ModConfig.zoomFov, 0.5);
            fovOption.method_41748((int) Math.round(currentFovOverride));
        } else if (wasZooming) {
            fovOption.method_41748((int) normalFov);
            currentFovOverride = -1;
        }
        wasZooming = zooming;
    }

    private static double lerp(double from, double to, double t) {
        return from + (to - from) * t;
    }
}
