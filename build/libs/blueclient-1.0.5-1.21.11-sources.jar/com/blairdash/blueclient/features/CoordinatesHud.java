package com.blairdash.blueclient.features;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Shows the player's block coordinates. With no position set (-1) it sits in
 * the top-right corner, right-aligned. With a position set, X/Y is the
 * top-left of the text.
 */
public class CoordinatesHud {
    private static String text(class_310 client) {
        class_2338 pos = client.field_1724.method_24515();
        return String.format("X: %d  Y: %d  Z: %d", pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    /** The X actually used: the configured value, or the top-right default. */
    public static int effectiveX(class_310 client, int scaledWidth) {
        if (ModConfig.coordsX >= 0) return ModConfig.coordsX;
        String sample = client.field_1724 != null ? text(client) : "X: 0  Y: 0  Z: 0";
        return scaledWidth - client.field_1772.method_1727(sample) - 6;
    }

    public static int effectiveY() {
        return ModConfig.coordsY >= 0 ? ModConfig.coordsY : 6;
    }

    public static void render(class_332 ctx, class_310 client) {
        if (client.field_1724 == null) return;
        String text = text(client);
        int x = effectiveX(client, ctx.method_51421());
        int y = effectiveY();
        ctx.method_25303(client.field_1772, text, x, y, 0xFFFFFFFF);
    }
}