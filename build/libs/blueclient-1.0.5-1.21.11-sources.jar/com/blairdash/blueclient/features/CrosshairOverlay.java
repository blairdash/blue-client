package com.blairdash.blueclient.features;

import com.blairdash.blueclient.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;

/**
 * Draws a simple cross-shaped crosshair whose size/color come from ModConfig.
 * The vanilla crosshair is hidden by InGameHudMixin so this doesn't just
 * draw on top of the default one. If enemyCrosshairEnabled is on and the
 * player is currently looking at an entity (mob or player), the crosshair
 * switches to enemyCrosshairColor instead of the normal color.
 */
public class CrosshairOverlay {
    public static void register() {
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> {
            if (!ModConfig.customCrosshairEnabled) return;
            class_310 client = class_310.method_1551();
            if (client.field_1690.field_1842 || client.field_1724 == null) return;
            draw(ctx, client);
        });
    }

    private static boolean isLookingAtEntity(class_310 client) {
        class_239 target = client.field_1765;
        return target instanceof class_3966;
    }

        private static void draw(class_332 ctx, class_310 client) {
        int cx = ctx.method_51421() / 2;
        int cy = ctx.method_51443() / 2;
        int len = (int) (ModConfig.crosshairSize / 2);
        int gap = (int) ModConfig.crosshairGap;
        int thickness = Math.max(1, (int) ModConfig.crosshairThickness);

        boolean onEnemy = ModConfig.enemyCrosshairEnabled && isLookingAtEntity(client);
        int color = onEnemy ? ModConfig.enemyCrosshairColor : ModConfig.crosshairColor;

        ctx.method_25294(cx - gap - len, cy - thickness / 2, cx - gap, cy - thickness / 2 + thickness, color);
        ctx.method_25294(cx + gap, cy - thickness / 2, cx + gap + len, cy - thickness / 2 + thickness, color);
        ctx.method_25294(cx - thickness / 2, cy - gap - len, cx - thickness / 2 + thickness, cy - gap, color);
        ctx.method_25294(cx - thickness / 2, cy + gap, cx - thickness / 2 + thickness, cy + gap + len, color);

        if (client.field_1724 != null) {
            float cooldown = client.field_1724.method_7261(0.0f);
            if (cooldown < 1.0f) {
                drawAttackIndicator(ctx, cx, cy, cooldown);
            }
        }
    }

    /**
     * A simple stand-in for vanilla's crosshair attack indicator, since the
     * vanilla one is drawn inside the same method InGameHudMixin cancels.
     * Not pixel-identical to vanilla's icon, but restores the cooldown
     * feedback: a small bar under the crosshair that fills as it resets.
     */
    private static void drawAttackIndicator(class_332 ctx, int cx, int cy, float progress) {
        int barWidth = 20;
        int barHeight = 2;
        int y = cy + 12;
        int x = cx - barWidth / 2;

        ctx.method_25294(x, y, x + barWidth, y + barHeight, 0x80000000); // dim background
        int filled = (int) (barWidth * progress);
        ctx.method_25294(x, y, x + filled, y + barHeight, 0xFFFFFF00); // yellow fill
    }
}