package com.blairdash.blueclient.features;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Shows helmet, chestplate, leggings, boots, then (after a small gap)
 * mainhand and offhand, each with its item icon, durability bar, and
 * remaining durability. X/Y is the top-left of the item icons. If no
 * position is set (-1), it defaults to the bottom-right corner.
 */
public class ArmorHud {
    private static final class_1304[] SLOTS = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166,
            class_1304.field_6173, class_1304.field_6171
    };
    private static final int ROW_HEIGHT = 18;
    private static final int ICON_SIZE = 16;
    private static final int HANDS_GAP = 6;
    private static final int FIRST_HAND_INDEX = 4;
    private static final int MARGIN = 4;

    private static int contentHeight() {
        return (SLOTS.length - 1) * ROW_HEIGHT + HANDS_GAP + ICON_SIZE;
    }

    public static int defaultX(int scaledWidth) {
        return scaledWidth - ICON_SIZE - MARGIN - 2;
    }

    public static int defaultY(int scaledHeight) {
        return scaledHeight - MARGIN - contentHeight();
    }

    /** The X actually used: the configured value, or the bottom-right default. */
    public static int effectiveX(int scaledWidth) {
        return ModConfig.armorHudX >= 0 ? ModConfig.armorHudX : defaultX(scaledWidth);
    }

    public static int effectiveY(int scaledHeight) {
        return ModConfig.armorHudY >= 0 ? ModConfig.armorHudY : defaultY(scaledHeight);
    }

    public static void render(class_332 ctx, class_310 client) {
        if (client.field_1724 == null || client.field_1690.field_1842) return;

        int iconX = effectiveX(ctx.method_51421());
        int top = effectiveY(ctx.method_51443());

        for (int i = 0; i < SLOTS.length; i++) {
            class_1799 stack = client.field_1724.method_6118(SLOTS[i]);
            if (stack.method_7960()) continue;

            int rowY = top + i * ROW_HEIGHT + (i >= FIRST_HAND_INDEX ? HANDS_GAP : 0);
            ctx.method_51427(stack, iconX, rowY);
            ctx.method_51431(client.field_1772, stack, iconX, rowY);

            if (stack.method_7963()) {
                int max = stack.method_7936();
                int remaining = max - stack.method_7919();
                float fraction = max > 0 ? (float) remaining / max : 1.0f;
                int color = fraction > 0.5f ? 0xFF55FF55 : (fraction > 0.25f ? 0xFFFFFF55 : 0xFFFF5555);

                String text = String.valueOf(remaining);
                int textWidth = client.field_1772.method_1727(text);
                ctx.method_25303(client.field_1772, text, iconX - 4 - textWidth, rowY + 4, color);
            }
        }
    }
}