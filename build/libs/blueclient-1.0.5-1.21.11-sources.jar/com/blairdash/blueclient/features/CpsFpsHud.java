package com.blairdash.blueclient.features;

import com.blairdash.blueclient.ModConfig;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Tracks left/right click timestamps over a rolling 1-second window for CPS, plus current FPS. */
public class CpsFpsHud {
    private static final Deque<Long> leftClicks = new ArrayDeque<>();
    private static final Deque<Long> rightClicks = new ArrayDeque<>();
    private static boolean prevAttackDown = false;
    private static boolean prevUseDown = false;

    public static void tick(class_310 client) {
        if (client.field_1724 == null) return;
        long now = System.currentTimeMillis();

        class_304 attack = client.field_1690.field_1886;
        class_304 use = client.field_1690.field_1904;

        if (attack.method_1434() && !prevAttackDown) leftClicks.addLast(now);
        if (use.method_1434() && !prevUseDown) rightClicks.addLast(now);
        prevAttackDown = attack.method_1434();
        prevUseDown = use.method_1434();

        purgeOld(leftClicks, now);
        purgeOld(rightClicks, now);
    }

    private static void purgeOld(Deque<Long> deque, long now) {
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
    }

    public static void render(class_332 ctx, class_310 client) {
        int x = ModConfig.cpsFpsX;
        int y = ModConfig.cpsFpsY;
        int fps = client.method_47599();
        int cps = Math.max(leftClicks.size(), rightClicks.size());
        ctx.method_25303(client.field_1772, "FPS: " + fps, x, y, 0xFFFFFFFF);
        ctx.method_25303(client.field_1772, "CPS: " + cps, x, y + 10, 0xFFFFFFFF);
    }
}