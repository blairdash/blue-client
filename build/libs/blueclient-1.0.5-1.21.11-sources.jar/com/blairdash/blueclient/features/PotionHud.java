package com.blairdash.blueclient.features;

import com.blairdash.blueclient.ModConfig;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Lists active potion effects as "Effect Name II  45s" starting at the
 * configured X/Y. Effects with under 10 seconds left turn red.
 */
public class PotionHud {
    private static final int COLOR_NORMAL = 0xFFFFFFFF;
    private static final int COLOR_LOW = 0xFFFF5555;
    private static final int LOW_TICKS = 200; // 10 seconds

    public static void render(class_332 ctx, class_310 client) {
        if (client.field_1724 == null || client.field_1690.field_1842) return;

        List<class_1293> effects = new ArrayList<>(client.field_1724.method_6026());
        if (effects.isEmpty()) return;
        effects.sort(Comparator.comparing(class_1293::method_5586));

        int x = ModConfig.potionHudX;
        int y = ModConfig.potionHudY;
        for (class_1293 effect : effects) {
            String name = class_2561.method_43471(effect.method_5586()).getString();
            if (effect.method_5578() > 0) {
                name += " " + roman(effect.method_5578() + 1);
            }

            String time;
            int color = COLOR_NORMAL;
            if (effect.method_48559()) {
                time = "**";
            } else {
                time = ((effect.method_5584() + 19) / 20) + "s";
                if (effect.method_5584() < LOW_TICKS) color = COLOR_LOW;
            }

            ctx.method_25303(client.field_1772, name + "  " + time, x, y, color);
            y += 10;
        }
    }

    private static String roman(int n) {
        String[] numerals = { "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X" };
        return (n >= 1 && n < numerals.length) ? numerals[n] : String.valueOf(n);
    }
}