package com.blairdash.blueclient.features;

import com.blairdash.blueclient.ModConfig;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Shows W / A / S / D and the left / right mouse buttons. A key lights up
 * while it's held. Uses the game's own key bindings, so remapped keys work.
 *
 *        [ W ]
 *   [ A ] [ S ] [ D ]
 *   [ LMB ] [ RMB ]
 */
public class Keystrokes {
    private static final int KEY = 22;    // key size in scaled GUI pixels
    private static final int GAP = 2;
    private static final int DEFAULT_X = 6;

    private static final int IDLE_BG = 0x80000000;
    private static final int PRESSED_BG = 0xCCFFFFFF;
    private static final int IDLE_TEXT = 0xFFFFFFFF;
    private static final int PRESSED_TEXT = 0xFF000000;

    public static int width() {
        return 3 * KEY + 2 * GAP;
    }

    public static int height() {
        return 3 * KEY + 2 * GAP;
    }

    /** The X actually used: the configured value, or the left edge. */
    public static int effectiveX() {
        return ModConfig.keystrokesX >= 0 ? ModConfig.keystrokesX : DEFAULT_X;
    }

    /** The Y actually used: the configured value, or vertically centered. */
    public static int effectiveY(int scaledHeight) {
        return ModConfig.keystrokesY >= 0 ? ModConfig.keystrokesY : (scaledHeight - height()) / 2;
    }

    public static void render(class_332 ctx, class_310 client) {
        if (client.field_1690.field_1842) return;

        int x = effectiveX();
        int y = effectiveY(ctx.method_51443());
        int step = KEY + GAP;

        // Row 1: W
        drawKey(ctx, client, x + step, y, KEY, KEY, "W", client.field_1690.field_1894.method_1434());

        // Row 2: A S D
        int y2 = y + step;
        drawKey(ctx, client, x, y2, KEY, KEY, "A", client.field_1690.field_1913.method_1434());
        drawKey(ctx, client, x + step, y2, KEY, KEY, "S", client.field_1690.field_1881.method_1434());
        drawKey(ctx, client, x + 2 * step, y2, KEY, KEY, "D", client.field_1690.field_1849.method_1434());

        // Row 3: LMB RMB (together exactly as wide as the rows above)
        int y3 = y2 + step;
        int mouseWidth = (width() - GAP) / 2;
        drawKey(ctx, client, x, y3, mouseWidth, KEY, "LMB", client.field_1690.field_1886.method_1434());
        drawKey(ctx, client, x + mouseWidth + GAP, y3, mouseWidth, KEY, "RMB", client.field_1690.field_1904.method_1434());
    }

    private static void drawKey(class_332 ctx, class_310 client, int x, int y, int w, int h,
                                String label, boolean pressed) {
        ctx.method_25294(x, y, x + w, y + h, pressed ? PRESSED_BG : IDLE_BG);

        int textWidth = client.field_1772.method_1727(label);
        int textX = x + (w - textWidth) / 2;
        int textY = y + (h - 8) / 2;
        // Dark text on a white key looks smudged with a shadow, so only shadow idle keys.
        ctx.method_51433(client.field_1772, label, textX, textY, pressed ? PRESSED_TEXT : IDLE_TEXT, !pressed);
    }
}